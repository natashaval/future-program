package hellomysql.hellomysql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HellomysqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(HellomysqlApplication.class, args);
	}
}
