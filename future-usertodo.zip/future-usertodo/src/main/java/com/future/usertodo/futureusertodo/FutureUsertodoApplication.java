package com.future.usertodo.futureusertodo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FutureUsertodoApplication {

	public static void main(String[] args) {
		SpringApplication.run(FutureUsertodoApplication.class, args);
	}
}
